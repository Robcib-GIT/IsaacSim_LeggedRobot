import omni.ext
import omni.ui as ui

from .terrain_utils import *
from omni.isaac.core.utils.stage import add_reference_to_stage, get_current_stage
from omni.isaac.core.utils.prims import define_prim, get_prim_at_path
import omni.usd
import os

# Functions and vars are available to other extension as usual in python: `example.python_ext.some_public_function(x)`
def some_public_function(x: int):
    print("[omni.isaac.terrain_generator] some_public_function was called with x: ", x)
    return x ** x


# Any class derived from `omni.ext.IExt` in top level module (defined in `python.modules` of `extension.toml`) will be
# instantiated when extension gets enabled and `on_startup(ext_id)` will be called. Later when extension gets disabled
# on_shutdown() is called.
class OmniIsaacTerrain_generatorExtension(omni.ext.IExt):
    
    # ext_id is current extension id. It can be used with extension manager to query additional information, like where
    # this extension is located on filesystem.
    def on_startup(self, ext_id):
        print("[omni.isaac.terrain_generator] omni isaac terrain_generator startup")

        self._count = 0

        self._window = ui.Window("My Window", width=300, height=300)
        with self._window.frame:
            with ui.VStack():
                label = ui.Label("")


                def on_click():
                    self.get_terrain()
                    # self._count += 1
                    label.text = "Generate Terrain"

                def on_reset():
                    self.clear_terrain()
                    # self._count = 0
                    label.text = "Clear Stage"

                on_reset()

                with ui.HStack():
                    ui.Button("Add Terrain", clicked_fn=on_click)
                    ui.Button("Clear Stage", clicked_fn=on_reset)

    def on_shutdown(self):
        print("[omni.isaac.terrain_generator] omni isaac terrain_generator shutdown")

    # This deletes the terrain
    def clear_terrain(self):
        current_stage = get_current_stage()
        current_stage.RemovePrim("/World/terrain")
    
    # The stuff that makes terrain
    def get_terrain(self):
        stage = get_current_stage()
        # create all available terrain types
        num_terains = 1
        terrain_width = 12.
        terrain_length = 12.
        horizontal_scale = 0.6  # [m] 0.25 originariamente!!
        vertical_scale = 0.005  # [m]
        num_rows = int(terrain_width/horizontal_scale)
        num_cols = int(terrain_length/horizontal_scale)
        heightfield = np.zeros((num_terains*num_rows, num_cols), dtype=np.int16)

        def new_sub_terrain(): 
            return SubTerrain(width=num_rows, length=num_cols, vertical_scale=vertical_scale, horizontal_scale=horizontal_scale)

        # weird
        #heightfield[0:num_rows, :] = random_uniform_terrain(new_sub_terrain(), min_height=-0.2, max_height=0.2, step=0.2, downsampled_scale=0.5).height_field_raw
        #np.set_printoptions(threshold=np.inf) #Permite la impresión completa del array

        

        ruta_escritorio = os.path.join(os.path.expanduser("~"), "Desktop", "my_terrain.txt")
     
        
        # Asegurarte de que mi_array es un ndarray
        #if isinstance(heightfield, np.ndarray):
    # Convertir el array a una cadena
            #array_como_cadena = np.array2string(heightfield, separator=', ')
    
    # Abrir (o crear) un archivo de texto y escribir la cadena
        with open(ruta_escritorio, "r") as archivo:
            contenido=archivo.read()

        matriz = eval(contenido)
        matriz_np = np.array(matriz)
    

        
        
        vertices, triangles = convert_heightfield_to_trimesh(matriz_np, horizontal_scale=horizontal_scale, vertical_scale=vertical_scale, slope_threshold=1.5)
        

        position = np.array([-6.0, 48.0, 0])
        orientation = np.array([0.70711, 0.0, 0.0, -0.70711])
        add_terrain_to_stage(stage=stage, vertices=vertices, triangles=triangles, position=position, orientation=orientation)
